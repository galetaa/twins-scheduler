"""Adversary branch-set semantics."""
