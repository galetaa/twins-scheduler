"""Protocol models."""
