<!-- Validity controls and remaining limitations. -->

| Class | Risk | Control | Residual |
|---|---|---|---|
| Internal | checker or event-order artifact | independent Go/Python event loops; FIFO, LIFO, and 256 seeded orders | bounded local fixture, not a full production client |
| Construct | scheduler expressiveness confused with bug prevalence | claims use exact unsafe-observation language and explicit closure counterfactuals | no probability-of-discovery claim |
| External | overgeneralization from explicit schemas | two locking abstractions and a parametric quorum construction | no universal HotStuff/Tendermint claim |
| Conclusion | finite search mistaken for proof | symbolic Z3 obligations separated from bounded regression evidence | protocol-to-schema mapping remains an instantiation obligation |
| Proof assurance | formalization error shared across routes | SMT/CHC, custom certificate kernel, Go arithmetic, and two event-loop implementations | external human proof review or Lean migration remains desirable before submission |
| Novelty | hidden refinement/testing prior art | dated and scoped novelty statement with source register | absence of found work is not proof of absence |
